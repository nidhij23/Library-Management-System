-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 15, 2012 at 02:50 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookdatabase`
--

CREATE TABLE `bookdatabase` (
  `bookID` varchar(5) NOT NULL,
  `BName` varchar(40) NOT NULL,
  `Subject` varchar(20) NOT NULL,
  `Author` varchar(20) NOT NULL,
  `Publisher` varchar(30) NOT NULL,
  `Price` int(11) NOT NULL,
  `dp` varchar(30) NOT NULL,
  `Availability` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookdatabase`
--

INSERT INTO `bookdatabase` (`bookID`, `BName`, `Subject`, `Author`, `Publisher`, `Price`, `dp`, `Availability`) VALUES
('23445', 'Bhurchnadi', 'Microprocessors', 'Njhkhks', 'pdn publication', 230, '2.jpg', 5),
('123', 'nidhi', 'maths', 'coreman', 'abc', 123, 'hello.jpg', 2),
('23457', 'Advanced Engineering Mathematics', 'Mathematics', 'Erwin Kreyszig', 'Wiley Publication', 457, 'kreyszig.jpeg', 3),
('12398', 'Computer Networks', 'Computer Networks', 'Andrew S.Tanenbum', 'Pearson', 398, 'compnet.jpeg', 4),
('13404', 'Unix Concepts and Applications', 'Unix', 'Sumitabha Das', 'TMH', 404, 'unixcon.jpeg', 5),
('14260', 'Datasructures ', 'Datastructures', ' lipschutz', 'TMH', 260, 'datastruct.jpeg', 5),
('14350', 'data-structures-and-algorithm-analysis-i', 'Datastructures', 'mark allen weiss', 'pearson', 350, 'datastrucalgo.jpeg', 5),
('15506', 'Effective Java', 'Java', 'Joshua Bloch ', 'Pearson', 506, 'effectjava.jpeg', 5),
('30220', 'Engineering Thermodynamics', 'Thermodynamicsc', 'pk nag', 'TMH', 220, 'thermo.jpeg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `booktransaction`
--

CREATE TABLE `booktransaction` (
  `MemberID` varchar(40) NOT NULL,
  `BName` varchar(40) NOT NULL,
  `DateOfIssue` varchar(40) NOT NULL,
  `DateOfReturn` varchar(40) NOT NULL,
  `Count` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booktransaction`
--

INSERT INTO `booktransaction` (`MemberID`, `BName`, `DateOfIssue`, `DateOfReturn`, `Count`) VALUES
('1210207', 'nidhi', 'Fri Nov 02 12:49:45 IST 2012', 'Fri Nov 02 12:50:46 IST 2012', '0'),
('1210207', 'Advanced Engineering Mathematics', 'Fri Nov 02 13:00:16 IST 2012', 'Tue Nov 13 17:12:26 IST 2012', '1'),
('1210207', 'Effective Java', 'Fri Nov 02 13:03:57 IST 2012', 'Fri Nov 02 13:19:50 IST 2012', '1'),
('1210207', 'Computer Networks', 'Fri Nov 02 13:04:52 IST 2012', 'Fri Nov 02 13:07:30 IST 2012', '2'),
('1210207', 'Advanced Engineering Mathematics', 'Tue Nov 13 17:11:58 IST 2012', '-', '2'),
('1210207', 'Advanced Engineering Mathematics', 'Tue Nov 13 17:14:47 IST 2012', '-', '2');

-- --------------------------------------------------------

--
-- Table structure for table `memberdatabase`
--

CREATE TABLE `memberdatabase` (
  `Name` varchar(20) NOT NULL,
  `MemberID` varchar(10) NOT NULL,
  `Class` varchar(20) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `Year` varchar(20) NOT NULL,
  `dp` varchar(30) NOT NULL,
  `Count` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `memberdatabase`
--

INSERT INTO `memberdatabase` (`Name`, `MemberID`, `Class`, `Branch`, `Year`, `dp`, `Count`) VALUES
('nidhi jain', '1210207', 'btech', 'cse', '3', 'v.jpeg', 2),
('Harleen Walia', '1210186', 'btech', 'cse', '3', 'v.jpeg', 0),
('Twinkle Dhamija', '1210555', 'BTech', 'Chemical', '3', 'hello.jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE `userlogin` (
  `UserID` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`UserID`, `Password`) VALUES
('nidhi', 'nidhi123'),
('leena', 'leen123'),
('hello', 'hello123');
